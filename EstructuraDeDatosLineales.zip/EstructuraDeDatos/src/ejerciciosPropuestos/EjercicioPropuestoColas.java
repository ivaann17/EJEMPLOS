// Juan David Bejarano Chac�n, Iv�n Mu�oz G�mez y Diego Santos Fern�ndez.

package ejerciciosPropuestos;
import edLineales2021_22.*;
public class EjercicioPropuestoColas{
	public static void main(String[] args) {
		//Creaci�n de la cola "colaPersonas implementaci�n con cola din�mica
		ColaDinamica <Persona> colaPersonas = new ColaDinamica<>();

		//Creaci�n de 6 personas en la clase persona
		Persona persona1= new Persona("Jos� Perez", 22);
		Persona persona2= new Persona("Luc�a Rodriguez", 41);
		Persona persona3= new Persona("Sebasti�n Sanchez", 41);
		Persona persona4= new Persona("Marta Benavides", 35);
		Persona persona5= new Persona("Pedro Gil", 9);
		Persona persona6= new Persona("Ana Sanz", 14);

		//Siguiendo el enunciado introducimos las personas con enqueue.
		colaPersonas.enqueue(persona1);
		colaPersonas.enqueue(persona2);
		colaPersonas.enqueue(persona3);
		colaPersonas.enqueue(persona4);
		colaPersonas.enqueue(persona5);
		colaPersonas.enqueue(persona6);
		System.out.print(colaPersonas.toString());
		//Sacamos una persona con dequeue 
		colaPersonas.dequeue();
		System.out.println(" ");
		System.out.print(colaPersonas.toString());}

}
