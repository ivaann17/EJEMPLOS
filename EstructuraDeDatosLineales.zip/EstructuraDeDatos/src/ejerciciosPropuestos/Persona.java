package ejerciciosPropuestos;

/** En esta clase "Persona" se almacenan datos personales (nombre y edad de las personas). 
 * Tambi�n, mediante la sobreescritura del m�todo "compareTo" se pueden realizar comparaciones 
 * de edad entre las personas de la clase.
 * 
 *@author Juan David Bejarano Chac�n, Iv�n Mu�oz G�mez y Diego Santos Fern�ndez.
 *
 */

public class Persona implements Comparable<Persona> {
	String nombre;
	int edad;
	
	/** Constructor para los elementos de la clase Persona.
	* @param nombre El par�metro "nombre" ser� el nombre asignado a la persona.
	* @param edad El par�metro "edad" ser� la edad (en a�os) que se quiera asignar a la persona.
	*/
	
	public Persona(String nombre, int edad){
		this.nombre=nombre;
		this.edad=edad;
	}
	
	/** M�todo para establecer un nombre a una persona.
	* @param nombre  El par�metro "nombre" ser� el nombre asignado a la persona.
	*/
	
	public void setNombre( String nombre) {
		this.nombre=nombre;
	}
	
	/** M�todo para que el nombre de la persona sea devuelto.
	* @return Nombre de la persona seleccionada
	*/
	
	public String getNombre() {
		return nombre;
	}
	
	/** M�todo que establece la edad de la persona seleccionada.
	* @param edad Edad de la persona seleccionada.
	*/
	
	public void setEdad(int edad) {
		this.edad=edad;
	}
	
	/** M�todo que devuelve la edad de la persona seleccionada.
	* @return Edad de la persona seleccionada.
	*/
	
	public int getEdad() {
		return edad;
	}
	
	/** M�todo que devuelve un valor determinado (1: si la primera persona es mayor; 0: si las personas tienen la misma edad;
	* y -1: si la primera persona es de menor edad) al realizar la comparaci�n(sobre la edad) de dos personas.
	*@param comparado Nombre de la segunda persona.
	*@return Valor resultante de la comparaci�n (1, 0 o -1).
	*/
	
	public int compareTo(Persona comparado) {
		int valor;
		if ( this.getEdad()>comparado.getEdad()) {
			valor=1; 
		}
		else if (this.getEdad()==comparado.getEdad()) {
			valor=0;  
		}
		else {
			valor=-1; 
		}
		return valor;
	}
	
	/** M�todo que devuelve una descripci�n textual de la comparaci�n (sobre la edad) de dos personas.
	* @param comparado Persona con la que se realiza la comparaci�n.
	* @return Cadena de texto con el resultado.
	*/
	
	public String compareToTextual(Persona comparado){
		String valor;
		if ( this.getEdad()>comparado.getEdad()) {
			valor= this.getNombre()+" es mayor que "+comparado.getNombre() ; 
		}
		else if (this.getEdad()==comparado.getEdad()) {
			valor= this.getNombre()+" tiene la misma edad que "+comparado.getNombre() ;  
		}
		else {
			valor= this.getNombre()+" es menor que "+comparado.getNombre() ; 
		}
		return valor;
	}
	/** M�todo que devuelve todos los datos(con un determinado formato) almacenados en la persona seleccionada 
	*@return Cadena de texto con el resultado.
	*/
	
	public String toString() {
	    return nombre +" "+ edad +" a�os ";
	}
}
	
