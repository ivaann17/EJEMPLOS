// Juan David Bejarano Chac�n, Iv�n Mu�oz G�mez y Diego Santos Fern�ndez.

package ejerciciosPropuestos;
import edLineales2021_22.*;
public class EjercicioPropuestoPilas{
	public static void main(String[] args) {
	//Creaci�n de la pila "pilaPersonas
	PilaDinamica <Persona> pilaPersonas = new PilaDinamica<>();
		
	//Creaci�n de 6 personas en la clase persona
	Persona persona1= new Persona("Jos� Perez", 22);
	Persona persona2= new Persona("Luc�a Rodriguez", 41);
	Persona persona3= new Persona("Sebasti�n Sanchez", 41);
	Persona persona4= new Persona("Marta Benavides", 35);
	Persona persona5= new Persona("Pedro Gil", 9);
	Persona persona6= new Persona("Ana Sanz", 14);
	
	//�rdenes hacia la pila.
	pilaPersonas.push(persona1);
	pilaPersonas.push(persona2);
	pilaPersonas.push(persona3);
	pilaPersonas.push(persona4);
	pilaPersonas.push(persona5);
	pilaPersonas.push(persona6);
	System.out.print(pilaPersonas.toString());
	pilaPersonas.pop();
	System.out.print(pilaPersonas.toString());}
	
}
