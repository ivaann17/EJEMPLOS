package edLineales2021_22;

/** En esta clase "Nodo" se almacenan datos necesarios sobre la posici�n 
 * del nodo de una pila din�mica. 
 * 
 *@author Juan David Bejarano Chac�n, Iv�n Mu�oz G�mez y Diego Santos Fern�ndez.
 *
 * @param <T> Elemento gen�rico
 */
public class Nodo<T> {
	T element; 
	Nodo<T> proximo;
	  /** M�todo constructor para crear un nodo.
	 * @param element Donde apunta el nodo.
	 * @param proximo Siguiente elemento donde ir� el nodo.
	 */
	public Nodo(T element, Nodo<T> proximo) {
	        this.element = element;
	        this.proximo = proximo;
	    }
	
	/** M�todo para cambiar y establecer el elemento donde se encontrar� el nodo.
	 * @param element Elemento elegido 
	 */
	public void setElement (T element) {
		this.element= element;
	}
	
	/** M�todo que devuelve el elemento actual en que se encuentra el nodo.
	 * @return Elemento actual
	 */
	public T getElement() {
		return element; 
	}
	
	/** M�todo para cambiar y establecer el elemento siguiente al que apuntar� el nodo.
	 * @param proximo Elemento siguiente elegido 
	 */
	public void setProximo(Nodo<T> proximo) {
		this.proximo= proximo;
	}
	
	/** M�todo que devuelve el elemento siguiente al que apuntar� el nodo 
	 * @return Elemento siguiente
	 */
	public Nodo<T> getProximo() {
		return proximo;
	}
	
	 /** M�todo sobreescrito que devuelve todos los datos
	 * (con un determinado formato) correspondientes al nodo.
	 * @return Cadena de texto con el resultado.
	 */
	public String toString() {
	        return element + "\n";
	    }
}
