package edLineales2021_22;
import java.util.Arrays;

public class ColaDinamica<T> implements Cola<T> {

	private Nodo<T> front,rear;
	
	private int size;

	public ColaDinamica(){
		front=null;
		rear=null;
		this.size=0;
	}
	
	public void enqueue(T element) {
		Nodo<T> variable = new Nodo<T>(element, null);
		if (isEmpty()) {
			front=variable;
			rear=variable;
		}
		else {
			while (rear.getProximo() !=null){
				rear = rear.getProximo();
			}
			rear.setProximo(variable);
			rear=rear.getProximo();
		}
		size++;
	}
	
	public T dequeue() throws ExcepcionEstructuraVacia {
		T element;
		if (isEmpty()) throw new ExcepcionEstructuraVacia ("Error cola vacia");	
		else {
			element = front.getElement();
			front= front.getProximo();
			size--;
		}
		return element;
	}

	public T front() throws ExcepcionEstructuraVacia {
		if (isEmpty()) throw new ExcepcionEstructuraVacia ("Error cola vacia");	
		else {
			return front.getElement();
		}
	}

	public boolean isEmpty() {
		return size==0;
	}

	public int getsize() {
		return size;
	} 

	public String toString() {
		T element;
		int i=0;
		String [] cadena = new String[size];
		if (isEmpty()) throw new ExcepcionEstructuraVacia ("Error cola vacia");
		else {
			Nodo <T> valor;
			element=front.getElement();
			cadena[i]=element.toString();
			valor = front.getProximo();
			while (valor!=null) {
				element=valor.getElement();
				i++;
				cadena[i]=element.toString();
				valor=valor.getProximo();
			}
			return Arrays.toString(cadena);
		}
	}
}
