package edLineales2021_22;
import java.util.Arrays;

/** En esta clase se implementa la Estructura Abstracta de Datos "Pila" en su forma est�tica. Para ello, se implementan
 * las operaciones: "push", "pop", "top", "isEmpty" y "size".
 * Tambi�n, mediante la sobreescritura del m�todo "toString" se muestra el contenido de la pila 
 * de forma legible y textual.
 * 
 *@author Juan David Bejarano Chac�n, Iv�n Mu�oz G�mez y Diego Santos Fern�ndez.
 *
 * @param <T> Elemento gen�rico.
 */

public class PilaEstatica<T> implements Pila<T> {
		int n, t;
		T [] Pila;
		T element;
		PilaEstatica() {
			Pila = (T[]) new Object[n];
			this.t=-1;
			this.n=0;
	}	
  
	public void push(T element) {
		if (t == n-1) {
			T [] Pila2 = Arrays.copyOf(Pila, n+1);
			t++;
			n++;
			Pila2 [t]= element;
			this.Pila=Pila2;
		}
		else {
			t=t+1; 
			Pila [t]= element; 
		}
	}	


	public T pop() throws ExcepcionEstructuraVacia {
		if (isEmpty()) {
			throw new ExcepcionEstructuraVacia("La pila est� vac�a.");
		}
		else {
		element= Pila [t];
		t=t-1;
		}
		return element;
	  }	


	public T top() throws ExcepcionEstructuraVacia {
		if (isEmpty()==true) {
			throw new ExcepcionEstructuraVacia("La pila est� vac�a.");
		}
		else {
		return Pila[t]; 	
		}
	}
	public boolean isEmpty() {
		return t<0;
	}
	public int size() {
		return t+1;
	}
	public String toString() {
		  if (isEmpty()) {
			  throw new ExcepcionEstructuraVacia("Pila vacia");
		  }
		  else {
			  String pilaActual = "\nLa pila tendr� los siguiente valores: \n\n" +"{ ";
			  for (int i = t; i >=0; i--) 
			pilaActual += Pila[i] +" ";
			pilaActual += "}"+"\n\nSiendo el elemento colocado m�s a la izquierda el elemento m�s reciente en ser a�adido.\n";
			  return pilaActual;
	           }	       
		}
}