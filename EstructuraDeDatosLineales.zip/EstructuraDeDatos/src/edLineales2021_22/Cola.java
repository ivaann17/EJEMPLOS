package edLineales2021_22;
/** Esta interfaz implementa los m�todos que son utilizados en la realizaci�n de la Estructura Abstracta de Datos "Cola"
 *
 *@author Juan David Bejarano Chac�n, Iv�n Mu�oz G�mez y Diego Santos Fern�ndez.
 *
 * @param <T> Elemento gen�rico 
 * @see <a href="https://campusvirtual.uclm.es/pluginfile.php/2176555/mod_resource/content/5/Unit3.pdf">https://campusvirtual.uclm.es/pluginfile.php/2176555/mod_resource/content/5/Unit3.pdf</a>
 * @see <a href="https://campusvirtual.uclm.es/pluginfile.php/2176598/mod_resource/content/10/Pr%C3%A1cticasED_2020_21_Colas.pdf">https://campusvirtual.uclm.es/pluginfile.php/2176598/mod_resource/content/10/Pr%C3%A1cticasED_2020_21_Colas.pdf</a>
 */
 public interface Cola<T> {
		
		/**
		 * El m�todo "Enqueue" me introduce el elemento a la cola.
		 *
		 * @param element El elemento a introducir.
		 */
	 
		public void enqueue(T element);
		
		/**
		 * El m�todo "Dequeue" me quita el primer elemento de mi cola.
		 *
		 * @return El elemento eliminado.
		 * @throws ExcepcionEstructuraVacia Muestra un error de ejecuci�n cuando la pila est� vac�a.
		 */
		
		public T dequeue() throws ExcepcionEstructuraVacia;
		
		/**
		 * El m�todo "Front" realiza una operaci�n de consulta del primer elemento.
		 *
		 * @return El primer elemento de la cola.
		 * @throws ExcepcionEstructuraVacia Muestra un error de ejecuci�n cuando la pila est� vac�a.
		 */
		
		public T front() throws ExcepcionEstructuraVacia;
		
		/**
		 * Este m�todo comprueba si la cola est� vac�a.
		 *
		 * @return True, si la cola est� vacia. False, si la cola contiene alg�n elemento.
		 */
		
		public boolean isEmpty();
		
		/**
		 * Este m�todo me devuelve el tama�o de la cola.
		 *
		 * @return Tama�o de la cola.
		 */
		
		public int getsize();
		
		/**
		 * El m�todo toString nos permite mostrar la informaci�n completa del objeto cola, el valor de sus atributos.
		 *
		 * @return Cadena textual con los atributos de la cola.
		 */
		
		public String toString();
		}
