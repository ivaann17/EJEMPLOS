package edLineales2021_22;

/** Esta interfaz implementa los m�todos que son utilizados en la realizaci�n de la Estructura Abstracta de Datos "Pila"
 *@author Juan David Bejarano Chac�n, Iv�n Mu�oz G�mez y Diego Santos Fern�ndez.
 *
 * @param <T> Elemento gen�rico
 * @see <a href="https://campusvirtual.uclm.es/pluginfile.php/2176546/mod_resource/content/7/Unit2_ED.pdf">https://campusvirtual.uclm.es/pluginfile.php/2176546/mod_resource/content/7/Unit2_ED.pdf</a>
 * @see <a href="https://campusvirtual.uclm.es/pluginfile.php/2176596/mod_resource/content/6/Pr%C3%A1cticasED_2021_22_Pilas.pdf">https://campusvirtual.uclm.es/pluginfile.php/2176596/mod_resource/content/6/Pr%C3%A1cticasED_2021_22_Pilas.pdf</a>
 */

public interface Pila<T> { 
		
	 /** M�todo para introducir un elemento en la pila.
	 * @param element Elemento que se desea introducir
	 */
		
	public void push (T element);
	
	 /** M�todo para eliminar el elemento de la pila que ha sido introducio m�s recientemente.
	 * @return Elemento eliminado.
	 * @throws ExcepcionEstructuraVacia Muestra un error de ejecuci�n cuando la pila est� vac�a.
	 */
	
	public T pop () throws ExcepcionEstructuraVacia;
	
	/** M�todo para mostrar el elemento que se encuentra en la parte m�s alta de la pila (primero en salir).
	* 
	* @return Elemento en posici�n para salir de la pila.
	* @throws ExcepcionEstructuraVacia Muestra un error cuando la pila est� vac�a.
	*/
	
	public T top () throws ExcepcionEstructuraVacia; 
	
	/** M�todo que devuelve true si la pila est� vacia o false si contiene alg�n elemento.
	* @return True si la pila est� vac�a. False si la pila contiene alg�n elemento.
	*/
	
	public boolean isEmpty();
	
	 /** M�todo que devuelve el n�mero de elementos que contiene la pila.
	 * @return Posici�n en que se encuentra la �litma posici�n de la pila.
	 */
	
	public int size();
	
	 /** M�todo sobreescrito que devuelve todos los datos
	 * (con un determinado formato) almacenados en la pila.
	 * @return Cadena de texto con el resultado.
	 */
	
	public String toString();
	}
