package edLineales2021_22;
import java.util.Arrays;

public class ColaEstatica<T> implements Cola<T>{

	private int comienzo,size,fin;

	private T [] Cola;

	public ColaEstatica(int N) {
		Cola = (T[]) new Object[N];
		this.comienzo=0;
		this.fin=0;
		this.size=0;
	}	

	public void enqueue(T element){
		if (size+1<=Cola.length) {
			fin=(comienzo+size)%Cola.length;
			Cola[fin]=element;
			size++;
		}else {
			incrementarMatriz();
			fin=(comienzo+size)%Cola.length;
			Cola[fin]=element;
			size++;
		}
	}

	private void incrementarMatriz () {
		Cola=Arrays.copyOf(Cola, (size+1));
	}
		
	public  T dequeue() throws ExcepcionEstructuraVacia {
		T element;
		if (isEmpty()) throw new ExcepcionEstructuraVacia ("Error cola vacia");	
		else { 
			element=Cola[comienzo];
			comienzo=((comienzo+1)%Cola.length);
			size--;
			return element;
		}

	}

	public T front() throws ExcepcionEstructuraVacia {
		if (isEmpty()) throw new ExcepcionEstructuraVacia ("Error cola vacia");
		else {
			return Cola[comienzo];
		}
	}

	public boolean isEmpty() {
		return size==0;
	}

	public int getsize() {
		return size;
	}

	public String toString() {
		String cadena = "[ ";
		if (isEmpty()) throw new ExcepcionEstructuraVacia("Cola vacia");
		else {
			for (int i = comienzo; i < Cola.length; i++) {
				if (Cola[i] != null) {
				cadena = cadena.concat(Cola[i].toString());
				cadena = cadena.concat(" ");
				}
			}
			cadena = cadena.concat("]");
		}
		return cadena;
	}
}
