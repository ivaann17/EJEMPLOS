package edLineales2021_22;

/** Esta clase crea una excepci�n con un mensaje de error a partir de la herencia de la clase "RuntimeException".
 *
 *@author Juan David Bejarano Chac�n, Iv�n Mu�oz G�mez y Diego Santos Fern�ndez.
 *
 */

public class ExcepcionEstructuraVacia extends RuntimeException {

	/** Constructor de la clase para mostrar el error.
	* @param error Mensaje de error elegido.
	*/
	public ExcepcionEstructuraVacia (String error){
	super(error);
	}
	}
