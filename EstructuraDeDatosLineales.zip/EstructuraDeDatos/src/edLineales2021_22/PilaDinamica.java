package edLineales2021_22;

/** En esta clase se implementa la Estructura Abstracta de Datos "Pila" en su forma din�mica. Para ello, se implementan
 * las operaciones: "push", "pop", "top", "isEmpty" y "size".
 * Tambi�n, mediante la sobreescritura del m�todo "toString" se muestra el contenido de la pila 
 * de forma legible y textual.
 * 
 *@author Juan David Bejarano Chac�n, Iv�n Mu�oz G�mez y Diego Santos Fern�ndez.
 *
 * @param <T> Elemento gen�rico.
 */
public class PilaDinamica<T> implements Pila<T> {
	Nodo<T> top; 
	int size;
	
	public PilaDinamica(){
		top= null;
		size=0;
	}
		public void push(T element) {
		Nodo<T> variable = new Nodo<T>(element, top);
		top= variable; 
		this.size+=1; 
		}
	
		public T pop() throws ExcepcionEstructuraVacia {
		if (isEmpty()) {
			throw new ExcepcionEstructuraVacia("Pila vacia");
		}
		else {
			T element= top.getElement(); 
			 Nodo<T> variable = top.getProximo();
	         top = null;
	         top = variable;
	        this.size-=1;
	         return element;	
		}
		}
	
		public T top() throws ExcepcionEstructuraVacia {
		if (isEmpty()) {
			throw new ExcepcionEstructuraVacia("Pila vacia");
		}
		else {
		return 	top.getElement();
		}
		}
	
		public boolean isEmpty() {
			return top==null;
		}
	
		
		public int size() {
			return size;
		}
		public String toString() {
			  
		        if (isEmpty()) {
		        	throw new ExcepcionEstructuraVacia("Pila vacia");
		        } else {
		            String pilaActual = "\nLa pila tendr� los valores: \n\n";
		            Nodo<T> valor = top;
		            while (valor != null) {
		                pilaActual += valor.toString();
		                valor = valor.getProximo();
		          
		            }
		            pilaActual += "\nSiguiendo un orden de entrada de arriba (mas reciente) hacia abajo (fondo de la pila).\n";
		            return pilaActual;
		 
		        }
		}
}
